from setuptools import find_packages, setup

setup(
    name='mogas',
    packages=find_packages(),
    version='0.1.0',
    description='Mo-GaS: Motion & Gaze Selection for Atari Games',
    author='CS 7648 Team 1',
    license='MIT',
)
